/*
 * Open Chinese Convert
 *
 * Copyright 2020-2021 Carbo Kuo <byvoid@byvoid.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "opencc.h"
#include <pybind11/pybind11.h>

namespace py = pybind11;

PYBIND11_MODULE(opencc_clib, m) {
  py::class_<opencc::SimpleConverter>(m, "_OpenCC")
      .def(py::init<const std::string&>())
      .def("convert", py::overload_cast<const char*, size_t>(
                          &opencc::SimpleConverter::Convert, py::const_));

#ifdef VERSION
  m.attr("__version__") = VERSION;
#else
  m.attr("__version__") = "dev";
#endif
}
